#ifndef TEMP_CONVERTER_H
#define TEMP_CONVERTER_H

#ifdef __cplusplus
extern "C" {
#endif

double celsius_to_fahrenheit(double temp_celsius);
double fahrenheit_to_celsius(double temp_fahrenheit);

#ifdef __cplusplus
}
#endif

#endif